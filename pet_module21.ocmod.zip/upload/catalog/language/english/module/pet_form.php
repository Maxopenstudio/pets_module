<?php
// Heading
$_['error_pet'] = 'Please select a pet';
$_['error_breed'] = 'Please select a breed';
$_['error_age'] = 'Please insert age of pet';
$_['error_gender'] = 'Please select a gender';
$_['text_pets'] = 'Your pets';
$_['text_month'] = 'months';
$_['text_delete'] = 'Delete';
$_['text_add'] = 'Add pet';
$_['text_select_pet'] = 'Select a pet';
$_['text_select_breed'] = 'Select a breed';
$_['text_select_gender'] = 'Select a gender';
$_['text_insert_age'] = 'Age in month';
$_['text_man'] = 'Man';
$_['text_woman'] = 'Woman';

